// Write your code here
import './index.css'

const ContactProfile = props => {
  const {contactDetails, onDeleteContact} = props
  const {imgUrl, name, uniqueNo} = contactDetails

  const onDelete = () => {
    onDeleteContact(uniqueNo)
  }
  return (
    <li className="bg-container">
      <li className="profile-container">
        <img src={imgUrl} alt={name} className="image" />
        <h1 className="names">{name}</h1>
      </li>
      <div className="btn-container">
        <button type="button" className="button" onClick={onDelete}>
          Delete
        </button>
      </div>
    </li>
  )
}
export default ContactProfile
